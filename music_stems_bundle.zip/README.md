# Dark Japanese Trap (Stems Version)
This version outputs **separate WAV stems** for each layer of your dark Japanese trap beat.
## How to Run
1. Ensure Python 3.8+ is installed.
2. Run:
   ```bash
   python3 music_stems_generator.py
   ```
3. Each prompt creates its own folder with:
   - `piano.wav`
   - `bass_808.wav`
   - `hihat.wav`
   - `snare.wav`
   - `full_mix.wav`
## Options
Render a single prompt or change length:
```bash
python3 music_stems_generator.py --which 3 --duration 160
```
Free for learning and music production.
