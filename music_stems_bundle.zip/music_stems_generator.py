#!/usr/bin/env python3
"""
music_stems_generator.py
Generates separate WAV stems (piano, 808 bass, hi-hat, snare, and full mix)
for dark Japanese trap prompts (150 BPM, 2–3 minutes).
Pure Python version — no external dependencies.
"""
import os, math, wave, random, argparse
from array import array
SR=44100; AMP=0.7; BPM=150; SEC_PER_BEAT=60.0/BPM; OUTPUT_DIR="output"
def clamp(x,a=-1.0,b=1.0):return max(a,min(b,x))
def write_wav(filename,samples):
    os.makedirs(os.path.dirname(filename),exist_ok=True)
    with wave.open(filename,"w") as wf:
        wf.setnchannels(1); wf.setsampwidth(2); wf.setframerate(SR)
        frames=array('h',(int(clamp(s)*32767) for s in samples)); wf.writeframes(frames.tobytes())
def sine(f,t):return math.sin(2*math.pi*f*t)
def piano_note(freq,dur):
    out=[]; 
    for i in range(int(dur*SR)):
        t=i/SR; env=1.0 if t<0.01 else math.exp(-3*t/dur)
        val=(sine(freq,t)+0.5*sine(freq*2,t))*env*0.6; out.append(val)
    return out
def sub_808(freq,dur):
    out=[]; 
    for i in range(int(dur*SR)):
        t=i/SR; env=math.exp(-3*t); val=sine(freq,t)*env*1.2; out.append(val)
    return out
def hi_hat(dur):
    out=[]; 
    for i in range(int(dur*SR)):
        t=i/SR; env=math.exp(-10*t); val=random.uniform(-1,1)*env*0.6; out.append(val)
    return out
def snare(dur):
    out=[]; 
    for i in range(int(dur*SR)):
        t=i/SR; env=math.exp(-8*t); val=(random.uniform(-1,1)*0.9+sine(200,t)*0.2)*env; out.append(val)
    return out
NOTE_FREQ={'A2':110.0,'C4':261.6,'D4':293.6,'E4':329.6,'F4':349.2,'G4':392.0,'A4':440.0}
CHORDS=[['A3','C4','E4'],['F3','C4','F4'],['G3','D4','G4'],['E3','B3','E4']]
def freq(n):return NOTE_FREQ.get(n,440.0)
def mix_layers(layers):
    max_len=max(len(x) for x in layers); out=[0.0]*max_len
    for layer in layers:
        for i,v in enumerate(layer):out[i]+=v
    m=max(abs(x) for x in out) or 1; return [x/m*AMP for x in out]
def make_track(prompt_i,duration):
    total=int(duration*SR)
    piano,bass,hats,snareL=[0.0]*total,[0.0]*total,[0.0]*total,[0.0]*total
    beat=SEC_PER_BEAT; t=0.0
    while t<duration:
        ch=random.choice(CHORDS)
        for n in ch:
            f=freq(n); s=piano_note(f,1.2)
            for i,v in enumerate(s):
                idx=int((t*SR)+i)
                if idx<total:piano[idx]+=v
        if int(t/beat)%4 in (0,2):
            sub=sub_808(freq('A2'),0.8)
            for i,v in enumerate(sub):
                idx=int((t*SR)+i)
                if idx<total:bass[idx]+=v
        for h in range(4):
            st=t+h*(beat/4); hh=hi_hat(0.05)
            for i,v in enumerate(hh):
                idx=int((st*SR)+i)
                if idx<total:hats[idx]+=v*0.5
        if int(t/beat)%4 in (1,3):
            sn=snare(0.2)
            for i,v in enumerate(sn):
                idx=int((t*SR)+i)
                if idx<total:snareL[idx]+=v
        t+=beat
    return piano,bass,hats,snareL
PROMPTS=[
"Dark Japanese trap beat with emotional R&B piano intro and heavy 808s.",
"Hard-hitting dark trap with Japanese city pop piano scales.",
"Samurai noir trap beat with haunting Japanese piano medley.",
"Neo-Tokyo trap beat with elegant R&B piano and rain ambience.",
"Emotional dark trap with cinematic piano intro.",
"Dark Japanese trap beat with nostalgic anime piano and taiko drums."
]
def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--duration','-d',type=int,default=150)
    parser.add_argument('--which','-w',type=int,default=0)
    args=parser.parse_args(); os.makedirs(OUTPUT_DIR,exist_ok=True)
    picks=range(1,7) if args.which==0 else [args.which]
    for i in picks:
        name=f"prompt_{i:02d}_dark_japanese_trap"; folder=os.path.join(OUTPUT_DIR,name)
        os.makedirs(folder,exist_ok=True); print(f"Generating stems for prompt {i}...")
        p,b,h,s=make_track(i-1,args.duration)
        write_wav(os.path.join(folder,'piano.wav'),p)
        write_wav(os.path.join(folder,'bass_808.wav'),b)
        write_wav(os.path.join(folder,'hihat.wav'),h)
        write_wav(os.path.join(folder,'snare.wav'),s)
        full=mix_layers([p,b,h,s])
        write_wav(os.path.join(folder,'full_mix.wav'),full)
        print("Saved:",folder)
    print("All stems generated successfully!")
if __name__=="__main__":main()
